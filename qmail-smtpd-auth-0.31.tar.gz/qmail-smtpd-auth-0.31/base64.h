#ifndef BASE64_H
#define BASE64_H

extern int b64decode();
extern int b64encode();

#endif
